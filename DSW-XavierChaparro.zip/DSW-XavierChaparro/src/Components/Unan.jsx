import React from 'react';
import Routes from './Routes';

const Unan = () => (
    <div className="main_container">
        <Routes />
    </div>
);

export default Unan;