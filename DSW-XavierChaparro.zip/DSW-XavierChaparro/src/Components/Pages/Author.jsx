import React from 'react';

const Author = () => {
    return (
        <div></div>
    )
}
export default Author;